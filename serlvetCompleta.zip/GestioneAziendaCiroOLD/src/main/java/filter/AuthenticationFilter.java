package filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.logging.Logger;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {
    private static final Logger logger = Logger.getLogger(AuthenticationFilter.class.getName());

    public void init(FilterConfig fConfig) throws ServletException {}

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        String loginURI = httpRequest.getContextPath() + "/login.jsp";
        String forbiddenURI = httpRequest.getContextPath() + "/forbidden.jsp";
        String requestURI = httpRequest.getRequestURI();

        boolean isLoginRequest = requestURI.endsWith("/login.jsp") || requestURI.endsWith("/Login");
        boolean isForbiddenRequest = requestURI.equals(forbiddenURI);
        boolean isLoggedIn = (session != null && session.getAttribute("account") != null);
        String role = (String) (isLoggedIn ? session.getAttribute("role") : null);

        //le pagine che solo admin ha accesso
        boolean isAdminPage = requestURI.contains("/inserimento.jsp") || requestURI.contains("/InserimentoProgetto")
                || requestURI.contains("/inserimentoprogetto.jsp") || requestURI.contains("/AssociaDipendenteProgetto")
                || requestURI.contains("/Inserimento.jsp") || requestURI.contains("/UpdateAdminProfile");

        // guest
        boolean isGuestPage = requestURI.contains("/Inserimento") && !isAdminPage;

        

        if (isLoggedIn) {
            if (isAdminPage && !"admin".equals(role)) {
                httpResponse.sendRedirect(forbiddenURI);
            } else if (isGuestPage && !"guest".equals(role) && !"admin".equals(role)) {
                httpResponse.sendRedirect(forbiddenURI);
            } else {
                chain.doFilter(request, response);
            }
        } else {
            if (isLoginRequest || isForbiddenRequest) {
                chain.doFilter(request, response);
            } else {
                httpResponse.sendRedirect(loginURI);
            }
        }
    }

    public void destroy() {}
}
