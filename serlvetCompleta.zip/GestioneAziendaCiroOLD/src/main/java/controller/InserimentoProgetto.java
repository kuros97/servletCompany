package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.ProgettoRepository;
import dao.WorkingRepository;
import model.DtoDipendenteProgetto;
import model.Progetto;

@WebServlet("/InserimentoProgetto")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024, // 1MB
    maxFileSize = 1024 * 1024 * 5, // 5MB
    maxRequestSize = 1024 * 1024 * 10 // 10MB
)
public class InserimentoProgetto extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public InserimentoProgetto() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProgettoRepository repo = new ProgettoRepository();
        ArrayList<Progetto> array = new ArrayList<>();
        ArrayList<DtoDipendenteProgetto> array2 = new ArrayList<>();
        WorkingRepository wrepo = new WorkingRepository();
        ResultSet rs = repo.getProgetto();

        try {
            while (rs.next()) {
                Progetto p = new Progetto();
                p.setId(rs.getInt("id"));
                p.setNomeProgetto(rs.getString("nomeProgetto"));
                p.setDescrizione(rs.getString("descrizione"));
                p.setCosto(rs.getDouble("costo"));
                p.setImg(rs.getString("img"));

                int numDipendenti = wrepo.countDipendentiPerProgetto(p.getId());
                
                DtoDipendenteProgetto dp = new DtoDipendenteProgetto();
                dp.setIdProgetto(p.getId());
                dp.setNomeProgetto(p.getNomeProgetto());
                dp.setNumDipendenti(numDipendenti);
                
                array.add(p);
                array2.add(dp);
            }

            request.setAttribute("arraypr", array);
            request.setAttribute("arrayprdp", array2);

            RequestDispatcher rd = request.getRequestDispatcher("gestioneprogetti.jsp");
            rd.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
            request.setAttribute("msg", "Qualcosa è andato storto!");
            rd.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProgettoRepository repo = new ProgettoRepository();
        Progetto p = new Progetto();
        
        String costoString = request.getParameter("costo");
        Double costo = Double.parseDouble(costoString);

        p.setNomeProgetto(request.getParameter("nomeProgetto"));
        p.setDescrizione(request.getParameter("descrizione"));
        p.setCosto(costo);
        p.setImg(request.getParameter("img"));
        
        if (repo.inserimentoProgetto(p) > 0) {
            RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
            request.setAttribute("msg", "Inserimento avvenuto correttamente!");
            rd.forward(request, response);
        } else {
            RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
            request.setAttribute("msg", "Inserimento non avvenuto!");
            rd.forward(request, response);
        }
    }
}
