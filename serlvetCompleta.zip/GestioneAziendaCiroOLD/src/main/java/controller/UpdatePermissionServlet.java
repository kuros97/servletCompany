package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AccountRepository;
import model.AccountDTO;

/**
 * Servlet implementation class UpdatePermissionServlet
 */
@WebServlet("/updatePermission")
public class UpdatePermissionServlet extends HttpServlet {
    private AccountRepository accountRepository = new AccountRepository();
    

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cf = request.getParameter("cf");
        AccountRepository accountRepo = new AccountRepository();

        try {
            ResultSet rs = accountRepo.getDipAccByCf(cf);
            if (rs.next()) {
                AccountDTO accountDTO = new AccountDTO();
                accountDTO.setId(rs.getInt("id"));
                accountDTO.setNome(rs.getString("nome"));
                accountDTO.setCognome(rs.getString("cognome"));
                accountDTO.setDataDiNascita(rs.getDate("data_di_nascita"));
                accountDTO.setCf(rs.getString("codice_fiscale"));
                accountDTO.setStipendio(rs.getDouble("stipendio"));
                accountDTO.setSesso(rs.getBoolean("sesso"));
                accountDTO.setDataDiAssunzione(rs.getDate("data_di_assunzione"));
                accountDTO.setLuogoNascita(rs.getString("luogo_nascita"));
                accountDTO.setUsername(rs.getString("username"));
                accountDTO.setEmail(rs.getString("email"));
                accountDTO.setPassword(rs.getString("password"));
                accountDTO.setIdPermesso(rs.getInt("idPermesso"));
                accountDTO.setIdDipendente(rs.getInt("id"));

                request.setAttribute("account", accountDTO);

                RequestDispatcher rd = request.getRequestDispatcher("modifica.jsp");
                rd.forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String newPermission = request.getParameter("newPermission");
        AccountDTO currentUser = (AccountDTO) session.getAttribute("currentUser");

        if (currentUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Update permission in the database
        currentUser.setIdPermesso(Integer.parseInt(newPermission));
        boolean updated = accountRepository.updateDipAcc(currentUser);

        if (updated) {
            // If the current user is changing their own permission
            if (currentUser.getUsername().equals(session.getAttribute("username"))) {
                // Invalidate the session
                session.invalidate();
                // Redirect to login page
                response.sendRedirect("login.jsp");
            } else {
                // Otherwise, update the session attribute
                session.setAttribute("currentUser", currentUser);
                response.sendRedirect("admin.jsp");
            }
        } else {
            response.sendRedirect("error.jsp");
        }
    }
}
