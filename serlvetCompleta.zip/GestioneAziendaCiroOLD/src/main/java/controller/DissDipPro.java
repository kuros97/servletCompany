package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.WorkingRepository;

/**
 * Servlet implementation class DissDipPro
 */
@WebServlet("/DissDipPro")
public class DissDipPro extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private WorkingRepository workingRepository = new WorkingRepository();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int idDipendente = Integer.parseInt(request.getParameter("idDipendente"));
        int idProgetto = Integer.parseInt(request.getParameter("idProgetto"));

        boolean successo = workingRepository.dissociaDipendenteDaProgetto(idDipendente, idProgetto);
        if (successo) {
            request.setAttribute("successMessage", "Dipendente dissociato dal progetto con successo.");
        } else {
            request.setAttribute("errorMessage", "Errore durante la dissociazione del dipendente dal progetto.");
        }

        response.sendRedirect("GestioneDettaglioProgetto?id=" + idProgetto);
    }
}
