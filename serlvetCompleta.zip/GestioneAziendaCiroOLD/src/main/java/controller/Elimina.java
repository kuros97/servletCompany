package controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import dao.AccountRepository;
import model.Account;

import java.io.IOException;

@WebServlet("/Elimina")
public class Elimina extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cf = request.getParameter("cf");
        request.setAttribute("cf", cf);
        RequestDispatcher rd = request.getRequestDispatcher("eliminazione.jsp");
        rd.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cf = request.getParameter("cf");
        HttpSession session = request.getSession();
        Account currentAccount = (Account) session.getAttribute("account");
        
        if (currentAccount != null) {
            int currentUserId = currentAccount.getId();
            AccountRepository repo = new AccountRepository();

            boolean wasCurrentUserAdmin = repo.eliminaDipAcc2(cf, currentUserId);
            if (wasCurrentUserAdmin) {
                session.invalidate(); // Invalida la sessione
                response.sendRedirect("login.jsp"); // Reindirizza alla pagina di login
                return;
            }
        }

        RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
        request.setAttribute("msg", "Eliminazione avvenuta correttamente!");
        rd.forward(request, response);
    }
}
