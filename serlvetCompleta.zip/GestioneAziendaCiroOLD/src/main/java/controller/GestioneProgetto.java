package controller;

import dao.DipendenteRepository;
import dao.WorkingRepository;
import model.Dipendente;
import model.Progetto;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/GestioneDettaglioProgetto")
public class GestioneProgetto extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DipendenteRepository dipendenteRepository = new DipendenteRepository();
    private WorkingRepository workingRepository = new WorkingRepository();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int idProgetto = Integer.parseInt(request.getParameter("id"));

        Progetto progetto = workingRepository.getProgettoById(idProgetto);
        List<Dipendente> assignedDipendenti = workingRepository.getDipendentiByProgetto(idProgetto);
        List<Dipendente> unassignedDipendenti = workingRepository.getUnassignedDipendenti(idProgetto);

        request.setAttribute("progetto", progetto);
        request.setAttribute("assignedDipendenti", assignedDipendenti);
        request.setAttribute("unassignedDipendenti", unassignedDipendenti);

        RequestDispatcher rd = request.getRequestDispatcher("gestioneDettaglioProgetto.jsp");
        rd.forward(request, response);
    }
}
