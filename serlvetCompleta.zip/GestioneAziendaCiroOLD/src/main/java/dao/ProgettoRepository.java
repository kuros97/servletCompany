package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Connessione;
import model.Progetto;

public class ProgettoRepository {
    
    public ProgettoRepository() {
	}

	public int inserimentoProgetto(Progetto p) {
        int num = 0;
        Connection conn = Connessione.getConnection();
        String sql = "INSERT INTO progetti(nomeProgetto, descrizione, costo, img) VALUES(?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNomeProgetto());
            ps.setString(2, p.getDescrizione());
            ps.setDouble(3, p.getCosto());
            ps.setString(4, p.getImg());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return num;
    }

    public ResultSet getProgetto() {
        Connection conn = Connessione.getConnection();
        String sql = "SELECT * FROM progetti";
        ResultSet rs = null;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public ResultSet getProgettoById(int id) {
        Connection conn = Connessione.getConnection();
        String sql = "SELECT * FROM progetti WHERE id = ?";
        ResultSet rs = null;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }

    public boolean eliminaProgetto(int id) {
        Connection conn = null;
        try {
            conn = Connessione.getConnection();
            String sql = "DELETE FROM progetti WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean eliminaProgetto2(int idProgetto) {
        Connection conn = null;
        PreparedStatement stmtRemoveAssociations = null;
        PreparedStatement stmtDeleteProject = null;
        boolean deleted = false;

        try {
            conn = Connessione.getConnection();
            conn.setAutoCommit(false);

            // Rimuovi le associazioni dei dipendenti
            String queryRemoveAssociations = "DELETE FROM workings WHERE idProgetto = ?";
            stmtRemoveAssociations = conn.prepareStatement(queryRemoveAssociations);
            stmtRemoveAssociations.setInt(1, idProgetto);
            stmtRemoveAssociations.executeUpdate();

            // Elimina il progetto
            String queryDeleteProject = "DELETE FROM progetti WHERE id = ?";
            stmtDeleteProject = conn.prepareStatement(queryDeleteProject);
            stmtDeleteProject.setInt(1, idProgetto);
            int rowsAffected = stmtDeleteProject.executeUpdate();

            if (rowsAffected > 0) {
                conn.commit();
                deleted = true;
            } else {
                conn.rollback();
            }
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            try {
                if (stmtRemoveAssociations != null)
                    stmtRemoveAssociations.close();
                if (stmtDeleteProject != null)
                    stmtDeleteProject.close();
                if (conn != null)
                    conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return deleted;
    }


    public int aggiornaProgetto(Progetto p) {
        int num = 0;
        Connection conn = Connessione.getConnection();
        String sql = "UPDATE progetti SET nomeProgetto = ?, descrizione = ?, costo = ?, img = ? WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getNomeProgetto());
            ps.setString(2, p.getDescrizione());
            ps.setDouble(3, p.getCosto());
            ps.setString(4, p.getImg());
            ps.setInt(5, p.getId());
            num = ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return num;
    }

    public List<Progetto> getAllProgetti() {
        Connection conn = Connessione.getConnection();
        List<Progetto> progetti = new ArrayList<>();
        String sql = "SELECT * FROM progetti";
        try (PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Progetto proj = new Progetto();
                proj.setId(rs.getInt("id"));
                proj.setNomeProgetto(rs.getString("nomeProgetto"));
                proj.setDescrizione(rs.getString("descrizione"));
                proj.setCosto(rs.getDouble("costo"));
                proj.setImg(rs.getString("img"));
                progetti.add(proj);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            Connessione.closeConnection(conn);
        }
        return progetti;
    }
    public List<Progetto> getProgettiPerDipendente(int idDipendente) throws SQLException {
    	Connection conn = Connessione.getConnection();
        List<Progetto> progetti = new ArrayList<>();

        String query = "SELECT p.* FROM progetti p " +
                       "JOIN workings w ON p.id = w.idProgetto " +
                       "JOIN dipendenti d ON w.idDipendente = d.id " +
                       "WHERE d.id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, idDipendente);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nomeProgetto = rs.getString("nomeProgetto");
                String descrizione = rs.getString("descrizione");
                int costo = rs.getInt("costo");

                Progetto progetto = new Progetto(id, nomeProgetto, descrizione, costo);
                progetti.add(progetto);
            }
        }

        return progetti;
    }
}
    
    
    
    
    
    
    
    
    

