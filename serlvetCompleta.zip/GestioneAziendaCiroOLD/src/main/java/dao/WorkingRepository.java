package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import model.Connessione;
import model.Dipendente;
import model.Progetto;

public class WorkingRepository {

	public boolean associaDipendenteProgetto(int idDipendente, int idProgetto) {
		Connection conn = Connessione.getConnection();
		String sql = "INSERT INTO workings (idDipendente, idProgetto) VALUES (?, ?)";
		boolean isSuccess = false;

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, idDipendente);
			ps.setInt(2, idProgetto);
			int rowsAffected = ps.executeUpdate();
			isSuccess = rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Connessione.closeConnection(conn);
		}

		return isSuccess;
	}

	public boolean coppiaExists(int idDipendente, int idProgetto) {
		Connection conn = Connessione.getConnection();
		String sql = "SELECT * FROM workings WHERE idDipendente = ? AND idProgetto = ?";
		boolean exists = false;

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, idDipendente);
			ps.setInt(2, idProgetto);
			try (ResultSet rs = ps.executeQuery()) {
				exists = rs.next();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Connessione.closeConnection(conn);
		}

		return exists;
	}

	public ResultSet getAllWorkings() {
		Connection conn = Connessione.getConnection();
		String sql = "SELECT w.idDipendente, d.nome AS nomeDipendente, d.cognome AS cognomeDipendente, w.idProgetto, p.nomeProgetto AS nomeProgetto "
				+ "FROM workings w " + "JOIN dipendenti d ON w.idDipendente = d.id "
				+ "JOIN progetti p ON w.idProgetto = p.id";
		ResultSet rs = null;

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}

	public boolean dissociaDipendenteDaProgetto(int idDipendente, int idProgetto) {
		Connection conn = Connessione.getConnection();
		String sql = "DELETE FROM workings WHERE idDipendente = ? AND idProgetto = ?";

		boolean isSuccess = false;

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, idDipendente);
			ps.setInt(2, idProgetto);
			int rowsAffected = ps.executeUpdate();
			isSuccess = rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Connessione.closeConnection(conn);
		}

		return isSuccess;
	}

	public int countDipendentiPerProgetto(int idProgetto) {
		Connection conn = Connessione.getConnection();
		String sql = "SELECT COUNT(*) AS count FROM workings WHERE idProgetto = ?";
		int count = 0;

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, idProgetto);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					count = rs.getInt("count");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Connessione.closeConnection(conn);
		}

		return count;
	}

	public Progetto getProgettoById(int idProgetto) {
		Connection conn = Connessione.getConnection();
		String sql = "SELECT * FROM progetti WHERE id = ?";
		Progetto progetto = null;

		try (PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.setInt(1, idProgetto);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					progetto = new Progetto();
					progetto.setId(rs.getInt("id"));
					progetto.setNomeProgetto(rs.getString("nomeProgetto"));
					progetto.setDescrizione(rs.getString("descrizione"));
					progetto.setCosto(rs.getDouble("costo"));
					progetto.setImg(rs.getString("img"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			Connessione.closeConnection(conn);
		}

		return progetto;
	}

	public List<Dipendente> getDipendentiByProgetto(int idProgetto) {
	    Connection conn = Connessione.getConnection();
	    String sql = "SELECT d.id, d.nome, d.cognome, " +
	                 "(SELECT COUNT(*) FROM workings w2 WHERE w2.idDipendente = d.id) AS numProgetti " +
	                 "FROM dipendenti d " +
	                 "JOIN workings w ON d.id = w.idDipendente " +
	                 "WHERE w.idProgetto = ? " +
	                 "GROUP BY d.id, d.nome, d.cognome";
	    List<Dipendente> dipendenti = new ArrayList<>();

	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, idProgetto);
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                Dipendente dipendente = new Dipendente();
	                dipendente.setId(rs.getInt("id"));
	                dipendente.setNome(rs.getString("nome"));
	                dipendente.setCognome(rs.getString("cognome"));
	                dipendente.setNumProgetti(rs.getInt("numProgetti"));
	                dipendenti.add(dipendente);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        Connessione.closeConnection(conn);
	    }

	    return dipendenti;
	}


	public List<Dipendente> getUnassignedDipendenti(int idProgetto) {
	    Connection conn = Connessione.getConnection();
	    String sql = "SELECT d.id, d.nome, d.cognome, " +
	                 "(SELECT COUNT(*) FROM workings w2 WHERE w2.idDipendente = d.id) AS numProgetti " +
	                 "FROM dipendenti d " +
	                 "LEFT JOIN workings w ON d.id = w.idDipendente " +
	                 "WHERE d.id NOT IN (SELECT idDipendente FROM workings WHERE idProgetto = ?) " +
	                 "GROUP BY d.id, d.nome, d.cognome";
	    List<Dipendente> dipendenti = new ArrayList<>();

	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, idProgetto);
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                Dipendente dipendente = new Dipendente();
	                dipendente.setId(rs.getInt("id"));
	                dipendente.setNome(rs.getString("nome"));
	                dipendente.setCognome(rs.getString("cognome"));
	                dipendente.setNumProgetti(rs.getInt("numProgetti"));
	                dipendenti.add(dipendente);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        Connessione.closeConnection(conn);
	    }

	    return dipendenti;
	}
	
	public List<Progetto> getProgettiPerDipendente(int idDipendente) {
	    Connection conn = Connessione.getConnection();
	    String sql = "SELECT p.* FROM progetti p JOIN workings w ON p.id = w.idProgetto WHERE w.idDipendente = ?";
	    List<Progetto> progetti = new ArrayList<>();
	    Logger logger = Logger.getLogger(WorkingRepository.class.getName());

	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        logger.info("Executing query to get projects for dipendente ID: " + idDipendente);
	        ps.setInt(1, idDipendente);
	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                Progetto progetto = new Progetto();
	                progetto.setId(rs.getInt("id"));
	                progetto.setNomeProgetto(rs.getString("nomeProgetto"));
	                progetto.setDescrizione(rs.getString("descrizione"));
	                progetto.setCosto(rs.getDouble("costo"));
	                progetto.setImg(rs.getString("img"));
	                progetti.add(progetto);
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        logger.severe("SQLException: " + e.getMessage());
	    } finally {
	        Connessione.closeConnection(conn);
	    }

	    logger.info("Number of projects found: " + progetti.size());
	    return progetti;
	}
	
	



	
}