package model;

public class ProAccDTO {
	private int id;
	private String nomeProgetto;
	
	private boolean assegnato;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNomeProgetto() {
		return nomeProgetto;
	}
	public void setNomeProgetto(String nomeProgetto) {
		this.nomeProgetto = nomeProgetto;
	}
	public boolean isAssegnato() {
		return assegnato;
	}
	public void setAssegnato(boolean assegnato) {
		this.assegnato = assegnato;
	}
	
	

}
