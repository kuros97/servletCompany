package model;

import java.util.Objects;


public class Progetto {
	
	private int id;
	private String descrizione;
	private String nomeProgetto;
	private double costo;
	private String img;
	
	

	public Progetto(int id2, String nomeProgetto2, String descrizione2, int costo2) {
		// TODO Auto-generated constructor stub
	}
	public Progetto() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public String getNomeProgetto() {
		return nomeProgetto;
	}
	public void setNomeProgetto(String nomeProgetto) {
		this.nomeProgetto = nomeProgetto;
	}
	
	@Override
	public String toString() {
		return "Progetto [id=" + id + ", descrizione=" + descrizione + ", nomeProgetto=" + nomeProgetto + ", costo" + costo +",img"+img;
	}
	@Override
	public int hashCode() {
		return Objects.hash(costo, descrizione, id, img, nomeProgetto);
	}
	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Progetto other = (Progetto) obj;
		return Double.doubleToLongBits(costo) == Double.doubleToLongBits(other.costo)
				&& Objects.equals(descrizione, other.descrizione) && id == other.id && Objects.equals(img, other.img)
				&& Objects.equals(nomeProgetto, other.nomeProgetto);
	}
	public double getCosto() {
		return costo;
	}
	public void setCosto(double costo) {
		this.costo = costo;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
	

}
