package model;

public class Permesso {
    private int id;
    private String nomePermesso;

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomePermesso() {
        return nomePermesso;
    }

    public void setNomePermesso(String nomePermesso) {
        this.nomePermesso = nomePermesso;
    }
}
