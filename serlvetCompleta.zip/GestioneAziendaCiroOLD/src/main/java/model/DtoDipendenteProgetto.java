package model;

public class DtoDipendenteProgetto{
    private int idDipendente;
    private String nomeDipendente;
    private String cognomeDipendente;
    private int idProgetto;
    private String nomeProgetto;
    private int numDipendenti;

    public int getIdDipendente() {
        return idDipendente;
    }

    public void setIdDipendente(int idDipendente) {
        this.idDipendente = idDipendente;
    }

    public String getNomeDipendente() {
        return nomeDipendente;
    }

    public void setNomeDipendente(String nomeDipendente) {
        this.nomeDipendente = nomeDipendente;
    }

    public String getCognomeDipendente() {
        return cognomeDipendente;
    }

    public void setCognomeDipendente(String cognomeDipendente) {
        this.cognomeDipendente = cognomeDipendente;
    }

    public int getIdProgetto() {
        return idProgetto;
    }

    public void setIdProgetto(int idProgetto) {
        this.idProgetto = idProgetto;
    }

    public String getNomeProgetto() {
        return nomeProgetto;
    }

    public void setNomeProgetto(String nomeProgetto) {
        this.nomeProgetto = nomeProgetto;
    }

	public int getNumDipendenti() {
		return numDipendenti;
	}

	public void setNumDipendenti(int numDipendenti) {
		this.numDipendenti = numDipendenti;
	}

	
}
